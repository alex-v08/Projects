package com.dh.clinica.exceptions;

public class BadRequestException extends Throwable {
    public BadRequestException(String s) {

    }
}
