package com.dh.clinica.exceptions;

public class BussinessException extends RuntimeException {

    public BussinessException(String message) {

        super(message);
    }
}
