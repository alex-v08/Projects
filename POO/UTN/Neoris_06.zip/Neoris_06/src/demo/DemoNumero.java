package demo;

public class DemoNumero
{
	public static void main(String[] args)
	{
		Object n = new Numero(10);
		Object m = new Numero(10);
		
		if( m.equals(10) )
		{
			System.out.println("Son iguales!");
		}
	}
}
