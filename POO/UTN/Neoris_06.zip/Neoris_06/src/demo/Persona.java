package demo;

public class Persona
{
	private int dni;
	private String nombre;

	
	public int getDni()
	{
		return dni;
	}
	
	public void setDni(int x)
	{
		dni=x;
	}
	
	public String getNombre()
	{
		return nombre;
	}
	
	public void setNombre(String nombre)
	{
		this.nombre=nombre;
	}
	
	
}
