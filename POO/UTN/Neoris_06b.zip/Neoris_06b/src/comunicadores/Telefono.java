package comunicadores;

public class Telefono
{

}
