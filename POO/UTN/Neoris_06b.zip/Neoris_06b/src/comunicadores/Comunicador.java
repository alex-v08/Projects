package comunicadores;

public interface Comunicador
{
	public void enviarMensaje(String mssg);
}
