package comunicadores;

public class Antiguedad
{

}
