package comunicadores;

public class Paloma extends Ave
{

}
