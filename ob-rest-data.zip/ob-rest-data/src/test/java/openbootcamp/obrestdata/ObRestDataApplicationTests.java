package openbootcamp.obrestdata;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ObRestDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
