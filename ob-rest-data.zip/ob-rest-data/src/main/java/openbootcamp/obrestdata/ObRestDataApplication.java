package openbootcamp.obrestdata;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ObRestDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(ObRestDataApplication.class, args);
	}

}
